import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-helped',
  templateUrl: './helped.component.html',
  styleUrls: ['./helped.component.scss']
})
export class HelpedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
